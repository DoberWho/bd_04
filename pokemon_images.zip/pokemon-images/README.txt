Pokemon Uranium as of 5/1/2020. Some images are missing from being "corrupt" when saving. Has pokemon, mega forms, event forms (anniversary, easter, etc), and a small select shiny forms

Pokemon Empyrean 1.0, the pokemon from /Graphics/Battlers

Special versions of pokemon from Pokemon Insurgence

Pokemon Solar Light & Lunar Dark as of 5/2/2020

Pokemon Sage. It appears like this game hasn't been released yet. Some images had a white background and couldn't be used.

Custom Fakemon sprites from Deviantart.

Names are all md5 hashes of the pixels of the image, to remove duplicate images.

I've removed any images smaller than 80x80, and larger than 160x160. I've also removed all images where width and height were not equal